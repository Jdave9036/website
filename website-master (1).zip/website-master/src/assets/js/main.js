/* global anchors:true */

(function() {
    'use strict';

    anchors.add('.docs-content h2, .docs-content h3, .docs-content h4, .docs-content h5, .docs-content h6, .docs-content .software-list th.section');
})();
