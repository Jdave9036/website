(function nojs (html) {
    'use strict';

    html.className = html.className.replace(/\bno-js\b/, '');
})(document.documentElement);
