---
title: Projects tagging, filtering and paging
---

We've just deployed AppVeyor update introducing paging, filtering and tagging on Projects page!

![projects filtered](/assets/img/posts/projects-tagging-filtering/projects-filtered.png)

Default page size is 10. You can change page size on profile page: <https://ci.appveyor.com/profile>

Tags can be specified on General tab of project settings (at the very bottom of the page):

![project tags settings](/assets/img/posts/projects-tagging-filtering/project-tags-settings.png)

Enjoy!

Feodor Fitsner,<br>
AppVeyor founder and developer

Follow us on Twitter: [@appveyor](https://twitter.com/appveyor)
