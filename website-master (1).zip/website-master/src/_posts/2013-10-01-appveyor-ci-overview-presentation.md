---
title: AppVeyor CI overview presentation
---

In this short presentation I'm talking about AppVeyor CI features and benefits, comparing it
to the existing continuous integration solutions and giving some hints about future plans.

<div class="row">
    <div class="columns small-12 medium-6">
        <div class="flex-video">
            <iframe src="//www.slideshare.net/slideshow/embed_code/26764707" width="425" height="355" class="slideshare-embed" allowfullscreen title="AppVeyor CI slideshare video"></iframe>
        </div>
    </div>
</div>

Enjoy!
